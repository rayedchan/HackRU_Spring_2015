/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hackruspring2015;

/**
 *
 * @author rayedchan
 */
public class MainObject 
{
    private Data data;
    
    public Object getData()
    {
        return this.data;
    }
    
    public void setData(Data data)
    {
        this.data = data;
    }
}

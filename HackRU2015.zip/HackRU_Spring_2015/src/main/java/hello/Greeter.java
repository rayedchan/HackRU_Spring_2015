package main.java.hello;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author dstroh
 */
public class Greeter {
    public String sayHello() {
        return "Hello World";
    }
}
